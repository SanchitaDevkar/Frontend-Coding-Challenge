package com.example.bookapi.service;

import com.example.bookapi.dto.DashboardStats;
import com.example.bookapi.entity.Book;
import com.example.bookapi.exception.ResourceNotFoundException;
import com.example.bookapi.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    @Override
    public Book getBookByIsbn(String isbn) {
        return bookRepository.findByIsbn(isbn)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with ISBN: " + isbn));
    }

    @Override
    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public Book updateBook(String isbn, Book bookDetails) {
        Book book = bookRepository.findByIsbn(isbn)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with ISBN: " + isbn));

        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setPublicationYear(bookDetails.getPublicationYear());

        return bookRepository.save(book);
    }

    @Override
    public void deleteBook(String isbn) {
        Book book = bookRepository.findByIsbn(isbn)
            .orElseThrow(() -> new ResourceNotFoundException("Book not found with ISBN: " + isbn));
        System.out.println("🗑 Deleting book: " + book);
        bookRepository.delete(book);
    }

    // ✅ Correct method definition (no semicolon)
    @Override
    public DashboardStats getDashboardStats() {
        long totalBooks = bookRepository.count();

        List<Object[]> authorData = bookRepository.findTop3Authors();
        List<String> topAuthors = authorData.stream()
                .map(a -> a[0].toString() + " (" + a[1] + ")")
                .toList();

        List<String> recentBooks = bookRepository.findTop5ByOrderByIdDesc().stream()
                .map(Book::getTitle)
                .toList();

        return new DashboardStats(totalBooks, topAuthors, recentBooks);
    }
}
