// src/main/java/com/example/bookapi/dto/DashboardStats.java
package com.example.bookapi.dto;

import java.util.List;

public class DashboardStats {
    private long totalBooks;
    private List<String> topAuthors;
    private List<String> recentBooks;

    public DashboardStats(long totalBooks, List<String> topAuthors, List<String> recentBooks) {
        this.totalBooks = totalBooks;
        this.topAuthors = topAuthors;
        this.recentBooks = recentBooks;
    }

    // Getters and Setters
    public long getTotalBooks() {
        return totalBooks;
    }

    public void setTotalBooks(long totalBooks) {
        this.totalBooks = totalBooks;
    }

    public List<String> getTopAuthors() {
        return topAuthors;
    }

    public void setTopAuthors(List<String> topAuthors) {
        this.topAuthors = topAuthors;
    }

    public List<String> getRecentBooks() {
        return recentBooks;
    }

    public void setRecentBooks(List<String> recentBooks) {
        this.recentBooks = recentBooks;
    }
}
