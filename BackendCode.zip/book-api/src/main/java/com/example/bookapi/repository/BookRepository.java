package com.example.bookapi.repository;

import com.example.bookapi.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface BookRepository extends JpaRepository<Book, Long> {

    // ✅ Basic operations
    Optional<Book> findByIsbn(String isbn);
    void deleteByIsbn(String isbn);
    boolean existsByIsbn(String isbn);

    // ✅ Top 3 authors with most books (JPQL - LIMIT not allowed, use setMaxResults in service or use native query)
    @Query(value = "SELECT b.author, COUNT(*) AS cnt FROM books b GROUP BY b.author ORDER BY cnt DESC LIMIT 3", nativeQuery = true)
    List<Object[]> findTop3Authors();

    // ✅ Recent 5 books by ID (latest added)
    List<Book> findTop5ByOrderByIdDesc();
}
