import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; // ✅ Required for [routerLink]
import { BookService } from '../book.service';
import { Book } from '../book';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [CommonModule, RouterModule], // ✅ RouterModule is required for routerLink
  templateUrl: './book-list.component.html'
})

export class BookListComponent implements OnInit {
  books: Book[] = [];
  token = localStorage.getItem('jwtToken') || '';

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.fetchBooks();
  }

  fetchBooks() {
    this.bookService.getBooks(this.token).subscribe({
      next: (data) => {
        this.books = data;
      },
      error: (err) => {
        console.error('Error fetching books:', err);
      }
    });
  }

  deleteBook(isbn: string) {
  if (confirm('Are you sure you want to delete this book?')) {
    this.bookService.deleteBook(isbn, this.token).subscribe({
      next: () => {
        this.books = this.books.filter(book => book.isbn !== isbn);
        alert('✅ Book deleted');
      },
      error: () => {
        alert('❌ Failed to delete book');
      }
    });
  }
}

}
