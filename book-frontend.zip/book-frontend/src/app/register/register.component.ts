import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router'; // ✅ Add this!

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule], // ✅ Add RouterModule here
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username: string = '';
  password: string = '';
  message: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  registerUser() {
  const body = { username: this.username, password: this.password };

  this.http.post('http://localhost:8081/auth/register', body, {
    headers: { 'Content-Type': 'application/json' }, 
    responseType: 'text',                            
    withCredentials: false                            
  }).subscribe({
    next: (res) => {
      this.message = '✅ ' + res;
      setTimeout(() => this.router.navigate(['/login']), 2000);
    },
    error: (err) => {
      this.message = '❌ ' + (err.error || 'Registration failed!');
      console.error('⚠️ Registration Error:', err);
    }
  });
  }
}
