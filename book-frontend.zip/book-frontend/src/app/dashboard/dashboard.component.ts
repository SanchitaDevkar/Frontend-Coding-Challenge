import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-5 text-center">
      <h1 class="text-success mb-4">📊 Dashboard</h1>

      <div class="row justify-content-center">
        <div class="col-md-3 m-2 p-4 border rounded border-success">
          <h4>Total Books</h4>
          <p class="text-success display-6">{{ totalBooks }}</p>
        </div>

        <div class="col-md-3 m-2 p-4 border rounded border-primary">
          <h4>Top Authors</h4>
          <ul class="list-unstyled">
            <li *ngFor="let author of topAuthors">👤 {{ author }}</li>
          </ul>
        </div>

        <div class="col-md-3 m-2 p-4 border rounded border-info">
          <h4>Recent Books</h4>
          <ul class="list-unstyled">
            <li *ngFor="let book of recentBooks">📘 {{ book }}</li>
          </ul>
        </div>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  totalBooks: number = 0;
  topAuthors: string[] = [];
  recentBooks: string[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const token = localStorage.getItem('jwtToken');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    this.http.get<any>('http://localhost:8081/api/books/dashboard', { headers })
      .pipe(
        catchError(err => {
          console.error('Error fetching dashboard stats:', err);
          return of(null); // return empty response
        })
      )
      .subscribe(data => {
        if (data) {
          this.totalBooks = data.totalBooks;
          this.topAuthors = data.topAuthors;
          this.recentBooks = data.recentBooks;
        }
      });
  }
}
