import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  error: string = '';
  success: boolean = false; // ✅ Add this line

  constructor(private http: HttpClient, private router: Router) {}

  login() {
    const body = { username: this.username, password: this.password };
    this.http.post<any>('http://localhost:8081/auth/login', body).subscribe({
      next: (res) => {
        const token = res.token;
        localStorage.setItem('jwtToken', token);
        this.success = true;
        this.error = '';
        setTimeout(() => {
          this.router.navigate(['/books']); // ✅ Redirect to books page
        }, 1500);
      },
      error: () => {
        this.error = 'Invalid credentials';
        this.success = false;
      }
    });
  }
}
