import { provideRouter, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { BookListComponent } from './book-list/book-list.component';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'books', component: BookListComponent }
];

export const appConfig = {
  providers: [
    provideRouter(routes),
    // add other providers like HttpClientModule if needed
  ]
};
