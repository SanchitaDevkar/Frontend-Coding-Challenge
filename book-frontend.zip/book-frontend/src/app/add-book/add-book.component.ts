import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-add-book',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-book.component.html',
})
export class AddBookComponent {
  title = '';
  author = '';
  isbn = '';
  publicationYear!: number;

  constructor(private http: HttpClient) {}

  addBook() {
    const token = localStorage.getItem('jwtToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const body = {
      title: this.title,
      author: this.author,
      isbn: this.isbn,
      publicationYear: this.publicationYear,
    };

    this.http.post('http://localhost:8081/api/books', body, { headers }).subscribe({
      next: () => {
        alert('✅ Book added successfully!');
        this.title = '';
        this.author = '';
        this.isbn = '';
        this.publicationYear = 0;
      },
      error: () => alert('❌ Error adding book'),
    });
  }
}
