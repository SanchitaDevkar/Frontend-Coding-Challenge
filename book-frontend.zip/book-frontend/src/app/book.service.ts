import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Book } from './book';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private apiUrl = 'http://localhost:8081/api/books';  // ✅ FIXED endpoint

  constructor(private http: HttpClient) {}

  getBooks(token: string): Observable<Book[]> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<Book[]>(this.apiUrl, { headers });
  }

  addBook(book: Book, token: string): Observable<Book> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post<Book>(this.apiUrl, book, { headers });
  }

  updateBook(isbn: string, book: Book, token: string): Observable<Book> {
  const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
  return this.http.put<Book>(`${this.apiUrl}/${isbn}`, book, { headers });
}

deleteBook(isbn: string, token: string): Observable<void> {
  const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
  return this.http.delete<void>(`${this.apiUrl}/${isbn}`, { headers });
}
}
