import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Book } from '../book';

@Component({
  selector: 'app-edit-book',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-book.component.html',
})
export class EditBookComponent implements OnInit {
  title = '';
  author = '';
  isbn = '';
  publicationYear: number = 0;
  token = localStorage.getItem('jwtToken') || '';

  constructor(
    private route: ActivatedRoute,
    private bookService: BookService,
    private router: Router
  ) {}

  ngOnInit() {
    this.isbn = this.route.snapshot.paramMap.get('isbn')!;
    this.bookService.getBooks(this.token).subscribe(books => {
      const book = books.find(b => b.isbn === this.isbn);
      if (book) {
        this.title = book.title;
        this.author = book.author;
        this.publicationYear = book.publicationYear;
      }
    });
  }

  updateBook() {
    const updatedBook: Book = {
      title: this.title,
      author: this.author,
      isbn: this.isbn,
      publicationYear: this.publicationYear
    };

    this.bookService.updateBook(this.isbn, updatedBook, this.token).subscribe({
      next: () => {
        alert('✅ Book updated!');
        this.router.navigate(['/books']);
      },
      error: () => alert('❌ Failed to update book'),
    });
  }
}
