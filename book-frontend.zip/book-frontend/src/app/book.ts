export interface Book {
  id?: number; // Optional for POST
  title: string;
  author: string;
  isbn: string;
  publicationYear: number;
}
