import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3">
      <a class="navbar-brand" routerLink="/books">📚 Book Hub</a>

      <div class="ms-auto d-flex align-items-center">
        <span class="text-light me-2 fw-bold" *ngIf="username">👤 {{ username }}</span>
        <a routerLink="/books" class="btn btn-outline-light mx-1">📚 Books</a>
        <a routerLink="/dashboard" class="btn btn-outline-light mx-1">📊 Dashboard</a>
        <a class="btn btn-danger mx-1" (click)="logout()">Logout</a>
      </div>
    </nav>
  `
})
export class NavbarComponent implements OnInit {
  username: string = '';

  constructor(private router: Router) {}

  ngOnInit() {
    const token = localStorage.getItem('jwtToken');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        this.username = payload.sub || ''; // assuming 'sub' contains username
      } catch (e) {
        console.error('Invalid token format', e);
      }
    }
  }

  logout() {
    localStorage.removeItem('jwtToken');
    this.router.navigate(['/login']);
  }
}
